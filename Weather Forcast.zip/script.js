var forecasts = [
                ["City","Day","Forecast","High","Low"],
                ["San Jose","Today","some sun","33°","24°"],
                ["San Jose","Tomorrow","some sun","31°","25°"],
                ["San Jose","Friday","some rain","25°","19°"],
                ["San Jose","Saturday","some clouds","27°","20°"],
                ["San Jose","Sunday","some rain","26°","21°"],
                ["Burbank","Today","very hot","40°","34°"],
                ["Burbank","Tomorrow","very hot","40°","32°"],
                ["Burbank","Friday","some sun","25°","21°"],
                ["Burbank","Saturday","windy","26°","21°"],
                ["Burbank","Sunday","windy","24°","18°"],
                ["Chicago","Today","some sun","32°","22°"],
                ["Chicago","Tomorrow","some clouds","25°","18°"],
                ["Chicago","Friday","some clouds","24°","19°"],
                ["Chicago","Saturday","thunderstorm","27°","23°"],
                ["Chicago","Sunday","thunderstorm","28°","19°"],
                ["Dallas","Today","very hot","42°","35°"],
                ["Dallas","Tomorrow","very hot","41°","33°"],
                ["Dallas","Friday","thunderstorm","26°","25°"],
                ["Dallas","Saturday","thunderstorm","34°","23°"],
                ["Dallas","Sunday","windy","32°","30°"],
                ["Philadelphia","Today","windy","28°","22°"],
                ["Philadelphia","Tomorrow","windy","25°","20°"],
                ["Philadelphia","Friday","some clouds","24°","17°"],
                ["Philadelphia","Saturday","thunderstorm","29°","24°"],
                ["Philadelphia","Sunday","some rain","28°","22°"],
                ]
function accept() {
    var cookies = document.getElementById("cookies");
    cookies.setAttribute("style","display: none");
}
function scaleChanged(scale) {
    var elements = document.getElementsByClassName("high");
    var count = elements.length;
    for (var k = 0; k< count; k++) {
        elements[k].innerText = convert(elements[k].innerText, scale);
    }
    elements = document.getElementsByClassName("low");
    for (var k = 0; k< count; k++) {
        elements[k].innerText = convert(elements[k].innerText, scale);
    }
}
function convert(temp, scale) {
    temp = parseInt(temp);
    var newTemp = 0;
    if (scale == "F") {
        newTemp = Math.round((temp * (9/5)) + 32);
    }
    else if (scale == "C") {
        newTemp = Math.round((temp - 32) / 1.8);
    }
    newTemp = newTemp + "°"
    return newTemp;
}
function changeCity(city) {
    document.querySelector(".header h1").innerText = city;
    var cityforecasts = [];
    var count = forecasts.length;
    var ptr = 0;
    for (var k = 0; k < count; k++) {
        if (forecasts[k][0] == city) {
            cityforecasts[ptr] = forecasts[k];
            ptr++;
        }
    }

    buildDailyForecasts(cityforecasts);

    // set the temperature scale to whatever is already 
    // selected. everything in the data array is in celcius
    // so only do this if the value is farenheit (f)
    var sel = document.getElementById("scale").value;
    if (sel == "F"){
        scaleChanged(sel);
    }

    alert("Loading weather report...");
}
function buildDailyForecasts(week) {
    var daily;
    for (var p = 0; p < week.length; p++) {
        daily = buildDailyForecast(week[p]);
    }
}
function buildDailyForecast(daily) {
    var vday = daily[1];
    var vforecast = daily[2];
    var vhigh = daily[3];
    var vlow = daily[4];
    var vimg = "";

    // get the right picture
    if (vforecast == "some sun") {
        vimg = "assets/some_sun.png";
    }
    else if (vforecast == "some clouds") {
        vimg = "assets/some_clouds.png";
    }
    else if (vforecast == "some rain") {
        vimg = "assets/some_rain.png";
    }
    else if (vforecast == "very hot") {
        vimg = "assets/very hot.jpg"
    }
    else if (vforecast == "windy") {
        vimg = "assets/windy.png";
    }
    else if (vforecast == "thunderstorm") {
        vimg = "assets/thunderstorm.png";
    }
    var dailyforecast = document.getElementById(vday);
    dailyforecast.querySelector("h3").innerText=vday;
    dailyforecast.querySelector("h4").innerText=vforecast;
    dailyforecast.querySelector(".weatherpic img").setAttribute("src",vimg);
    dailyforecast.querySelector(".weatherpic img").setAttribute("alt",vforecast);
    dailyforecast.querySelector(".temperatures .high").innerText=vhigh;
    dailyforecast.querySelector(".temperatures .low").innerText=vlow;
}
